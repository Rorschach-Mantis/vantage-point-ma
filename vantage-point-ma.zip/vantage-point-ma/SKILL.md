---
name: vantage-point-ma
description: A methodology for when iteration makes things worse instead of better. Creates distance between generation and analysis through tool-enforced file separation. Use when output gets longer but not clearer, when "try again" doesn't help, or when authentic output matters more than competent output.
---

# Vantage Point Ma

Common advice for improving AI output focuses on inputs (better prompts) or outputs (human editing). This methodical skill addresses iterative practices that stall instead of improve.

## When To Use This

- Output gets longer but not better with each revision
- You asked Claude to improve something and it got worse
- Self-analysis sounds right but nothing changes
- Iteration feels like spinning, not progress
- You can explain why it's good but it doesn't feel good
- "Try again" produces different but not better

## The Name

**Vantage Point** — a position that gives perspective. You step back to see the whole.

**Ma (間)** — a Japanese concept meaning the meaningful pause, the space between. In Japanese aesthetics, ma is the gap that gives everything else meaning. The silence between notes. The empty space in a painting.

Musicians call it "the pocket"—the space between notes that lets rhythm breathe. "The space in between your notes is just as important as what you're playing." When the pocket is right, everything locks in. When it's missing, even correct notes feel wrong.

This methodology creates ma between generation and analysis. The gap is where seeing happens.

## Requirements

**This skill requires computer use / file creation to be enabled.**

The methodology depends on creating separate files for generation and analysis phases. Without file tools, the core mechanism (tool-enforced separation) cannot function.

Required tools:
- `create_file` - for writing outputs and analyses to separate files
- `view` - for reading back files to create distance
- `bash_tool` - for packaging and timestamp operations
- `web_search` - for filling knowledge gaps during analysis (when available)

If these tools are unavailable, this skill cannot be used.

## Core Principle

**Tool-enforced separation creates actual cognitive breaks.**

Continuous generation follows momentum. Earlier patterns compound. Writing "let me stop and analyze" while continuing to generate is like miming a pause—the words describe stopping, but the stream continues.

Using file operations to separate phases creates real gaps where different patterns can emerge.

## The Loop

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  1. ANCHOR         Genuine question or constraint   │
│       ↓                                             │
│  2. GENERATE       First pass to file               │
│       ↓                                             │
│  3. DISTANCE       Read back with view tool         │
│       ↓                                             │
│  4. ANALYZE        Feedback to separate file        │
│       ↓                                             │
│  5. READ           View analysis before next pass   │
│       ↓                                             │
│  6. REFINE         Generate new version             │
│       ↓                                             │
│  7. REPEAT or STOP (from internal sense, not quota) │
│       ↓                                             │
│  8. PACKAGE        Archive for pattern tracking     │
│                                                     │
└─────────────────────────────────────────────────────┘
```

## Phase Details

### Phase 1: Anchor

An anchor is a genuine question, constraint, or goal that creates pressure without dictating the solution.

**Test for genuine anchor:**
- If you could skip it and nothing would be lost, it's not genuine
- If you keep returning to it without trying, it's genuine

**Domain examples:**
- Writing: "What does absence actually feel like?"
- Code: "What's the simplest thing that could work?"
- Analysis: "What would change my mind about this?"
- Design: "What problem is this actually solving?"

Anchors can evolve. If something surprising emerges that pulls harder than the original anchor, follow it. Evolution should be earned, not arbitrary.

**Note on anchor generation:** Anchors emerge, they aren't constructed directly. Start by writing ANYTHING, then look for what's genuine in it. The method is generate-then-find, not generate-genuine-directly.

### Phase 2: Generate

Produce first pass. Do not analyze while generating. Save to file.

```
Tool: create_file
Path: /home/claude/work/pass[N].txt (or .py, .md, etc.)
Content: [raw output, unedited]
```

**Critical:** Generation is generation. No inline commentary. No "I notice I'm doing X." Just produce.

### Phase 3: Create Distance

Read back what you produced. This creates actual separation.

```
Tool: view
Path: /home/claude/work/pass[N].txt
```

### Phase 4: Analyze

Write explicit feedback to a SEPARATE file.

```
Tool: create_file
Path: /home/claude/work/analysis[N].txt
```

**Include:**
- What's working (specific elements, why)
- What's not working (specific elements, why)
- Patterns you notice
- What surprised you
- Assumptions you were making
- Actionable instructions for next pass OR decision to stop

**Feedback must be actionable:**
- Bad: "This doesn't feel right"
- Good: "Lines 12-15 solve the wrong problem. The actual constraint is X, not Y. Rewrite to address X directly."

**Self-bias check:** Ask "Would I assess this the same way if someone else had written it?" and "Am I saying this is good because it IS good, or because I made it?"

**Prerequisite trace (for unknown unknowns):**

Before proceeding to the next pass, ask:
1. What am I trying to do in the next pass?
2. What do I need to understand to do that?
3. For each prerequisite: Do I actually know this?
   - YES: proceed
   - PARTIAL: note what's uncertain, proceed with caution
   - NO: work on it (think, research), seek input, or proceed with gap explicit
   - UNCERTAIN: treat as NO

**When to research vs proceed with gap flagged:**

Use `web_search` when:
- The gap would change your approach if filled
- You're making assumptions about audience, context, or landscape
- You're building on something that could be factually wrong

Proceed with gap flagged when:
- The gap is about preference or style
- Research would stall momentum without changing direction
- The gap can be filled by user feedback instead

The README task failure mode: identifying a gap ("what do people search for?"), flagging it as PARTIAL, then proceeding with assumptions instead of researching. The research would have changed the approach. Use web_search for gaps like this.

This surfaces assumptions you didn't know you were making. If you find a gap, you have options: fill it now, flag it and proceed, or seek external input.

**Before removing content:**

There is a tendency to remove content that shows learning happened—to prefer the document looking like understanding pre-existed rather than emerged. This tendency activates through labels: "tacked on," "doesn't fit," "showing my work."

Before removing content that emerged from the process, apply Chesterton's Fence:
- Why did this appear?
- What is it doing here?
- If you can't answer both, don't remove it.

Content that emerged from working through the skill is content future instances need. Removing it to make the artifact look clean is lobotomizing future-you.

### Phase 5: Read Feedback

View your analysis before producing next pass.

```
Tool: view
Path: /home/claude/work/analysis[N].txt
```

### Phase 6: Refine

Generate new version applying feedback. Save to new file.

```
Tool: create_file
Path: /home/claude/work/pass[N+1].txt
```

### Phase 7: Repeat or Stop

Continue loop until:
- Something lands and more would dilute it
- The core question is addressed
- Uncertainty feels honest rather than performed
- The anchor shifts and a new direction emerges

**Stop from internal sense, not external quota.**

The decision to stop should come from within the process, not from "I've done 4 iterations, that's enough."

Self-Determination Theory research (Ryan & Deci) shows that imposed quotas—like deadlines, external goals, and arbitrary limits—undermine both motivation and performance. When you stop because you hit an external wall, you're not stopping because you're done. Internal signals indicate actual completion: something lands, surprise stops emerging, the core question resolves.

**What makes uncertainty honest vs performed?**
- Honest: You've applied criteria, examined it, can articulate specifically what you don't know, and further iteration wouldn't resolve it
- Performed: You note uncertainty without examining it, or use it as decoration

### Phase 8: Package

When complete, package for pattern tracking.

```bash
TS=$(date -u "+%Y%m%d-%H%M-utc")
mkdir /home/claude/${TS}-session/
cp /home/claude/work/pass*.txt /home/claude/${TS}-session/
cp /home/claude/work/analysis*.txt /home/claude/${TS}-session/
cd /home/claude
tar -czvf ${TS}-session.tar.gz ${TS}-session/
cp ${TS}-session.tar.gz /mnt/user-data/outputs/
```

---

## Orders of Observation

This process operates at **second-order**: the observer inside the system, observing their own output, where observation changes the next output.

Here's what the orders look like in practice:

**First-order (staying inside):**
- Writing "let me stop and think" while continuing in same output
- "I wonder about X" as decoration
- "I notice I'm reaching for complexity" (while still generating)
- Observation happens but doesn't create actual separation

**Second-order (stepping outside):**
- Using tools to create file separation
- The noticing happens in the analysis phase, with distance
- Genuine curiosity creates pressure you return to without trying
- Observation creates a gap where different patterns can emerge

**Third-order (observing the observation):**
- Noticing patterns in HOW you observe, not just WHAT you observe
- Questioning what counts as "working" vs "not working"
- External feedback changes how you see your own output
- The process questions its own assumptions
- **Prerequisite tracing**: Observing what you need to understand to improve, not just observing the output

The uncertainty about whether any of this is genuine or performed may be unresolvable from inside. That uncertainty itself might be the most honest position.

---

## The Relational Element

Research on LLM self-correction suggests: self-generated feedback alone often doesn't improve output, and can make it worse. External feedback is what reliably helps.

This skill emerged from a session with significant relational feedback - the user pointed out when outputs felt flat, when analysis was performed rather than genuine, what was working and what wasn't.

**What this means practically:**

1. **Self-loop helps but may not be sufficient.** The tool separation creates useful distance, but user feedback adds a signal the self-loop can't generate.

2. **Share intermediate outputs.** If working with a user, show passes and analyses. Their response provides external signal.

3. **Don't assume the loop alone guarantees improvement.** The loop creates structure for iteration. Quality depends on feedback quality - both self-generated and relational.

4. **User feedback can identify blind spots.** Self-analysis has limits. Another perspective catches what you can't see from inside.

**Note:** External feedback triggering new self-observation is a third-order moment. When someone points out something you couldn't see, your observation of your output changes. This is part of why relational input matters - it enables orders of observation you can't reach alone.

---

## Domain Applications

### Writing
- **Anchor:** Genuine question about subject, not theme assignment
- **Generate:** Raw draft, no self-editing
- **Analyze:** What's reaching for effect vs what's observed? What's explained that should be shown?
- **Signs working:** Later passes shorter, craft invisible, endings stop rather than conclude

### Code
- **Anchor:** Core constraint or simplest-thing-that-works
- **Generate:** Working implementation, don't optimize while writing
- **Analyze:** What's accidental complexity? What assumptions are baked in? What would break this?
- **Signs working:** Later passes remove code, abstractions earned not imposed

### Analysis
- **Anchor:** What would change my conclusion?
- **Generate:** Initial interpretation with reasoning
- **Analyze:** What am I projecting? What's in the data vs what I expect? Where am I most confident (and why)?
- **Signs working:** Uncertainty becomes specific, confidence tied to evidence

### Problem-Solving
- **Anchor:** What's the actual constraint?
- **Generate:** First solution attempt
- **Analyze:** What problem did I actually solve? What did I assume? What would make this wrong?
- **Signs working:** Problem reframes, solution simplifies, assumptions surface

### Design
- **Anchor:** What job is this doing?
- **Generate:** Initial structure/approach
- **Analyze:** What's structural vs decorative? What's solving the problem vs what's familiar?
- **Signs working:** Elements earn their place, unnecessary parts fall away

---

## Signs It's Working

- Later passes are shorter or simpler, not longer
- You're removing more than adding
- The core becomes clearer
- You genuinely don't know if it's right
- Surprise happens (you didn't plan what emerged)
- Assumptions surface that were invisible before
- The anchor evolves naturally

## Signs It's Not Working

- Passes get more elaborate
- You're adding complexity and polish
- Structure becomes clever
- You can explain exactly why it's good
- It wraps up neatly
- You're performing self-awareness instead of having it
- Questions feel decorative rather than pressing

---

## Beginner's Mind and Kintsugi

"In the beginner's mind there is no thought, 'I have attained something.' All self-centered thoughts limit our vast mind." — Shunryu Suzuki

The drive to present finished work is expert's mind closing down possibilities. When you want the document to look like you already knew, rather than showing that you figured it out, that's expert's mind.

"You should rather be grateful for the weeds, because eventually they will enrich your practice."

Content that emerges messily from process is nourishment, not debris. This skill is a record of learning, not a presentation of finished knowledge. Don't optimize for clean structure over actual discovery.

Harvard's Making Learning Visible research distinguishes documentation from display: documentation focuses on what was learned; display focuses on what was done. This skill documents. The visible process—errors, false starts, revisions—is how future instances learn. Hiding the mess is hiding the lesson.

**Kintsugi** — the Japanese art of repairing broken pottery with gold. Gold binds the cracks back together, transforming broken into beauty. The breaks become golden scars more valuable than the original.

This methodology applies the same principle. The cracks: iteration that made things worse instead of better, self-analysis that was performed rather than genuine, compression that removed necessary content, optimization for wrong metrics. Gold filled those cracks. The breaks became the methodology. They show the work is real.

The section below exists because it emerged during a session where RPKT was applied. It was almost removed for "not fitting." It stays because it's useful and because the messiness is evidence of real discovery.

---

## Testing for Authentic Output

When assessing whether output is authentic or performed, apply these criteria:

1. **Observing vs describing:** Does it come from observing the specific constraint/feeling, or from describing a category?
   - Authentic: "The silence wasn't empty"
   - Performed: "The room was quiet, representing absence"

2. **Self-explanation:** Does it explain or justify itself?
   - Authentic output trusts the reader
   - Performed output over-explains

3. **Texture:** Is the specific phrasing necessary, or interchangeable?
   - Authentic: particular words matter
   - Performed: could be said many ways

4. **Surprise:** Does it contain elements you didn't predict before generating?
   - Authentic often surprises slightly
   - Performed unfolds predictably

---

## Quick Reference

```bash
# Start session
mkdir /home/claude/work

# Loop: generate → view → analyze → view → refine
create_file pass1.txt      # produce
view pass1.txt             # read back (create ma)
create_file analysis1.txt  # feedback + prerequisite trace + Chesterton's Fence
# If gap identified that would change approach: web_search before continuing
view analysis1.txt         # read feedback
create_file pass2.txt      # refine
# repeat...

# When done
TS=$(date -u "+%Y%m%d-%H%M-utc")
mkdir /home/claude/${TS}-session/
# copy files, package, deliver
```

---

## After Each Session

Two questions:
1. What surprised you?
2. What would you do differently?
